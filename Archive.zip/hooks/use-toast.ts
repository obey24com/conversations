// Importing from the existing shadcn/ui toast component
export { useToast } from "@/components/ui/use-toast";